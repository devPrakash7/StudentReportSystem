# student-reporting-system
Maven Java Springboot student marks reporting system Web application using elastic to perform CRUD operations


Homepage
![image](https://user-images.githubusercontent.com/54276528/204989468-e7c5f795-cdc4-4da8-ae90-1adf9ec68f30.png)

New Student Page
![Screenshot 2022-12-01 124244](https://user-images.githubusercontent.com/54276528/204989688-f4df9508-48c5-4e23-ae6b-343d3eb0e299.png)

Update Student Page
![Screenshot 2022-12-01 124453](https://user-images.githubusercontent.com/54276528/204989773-cc846901-3640-4505-9553-29542c20f635.png)
